<?php

return array(
    'code'=> 'changyan',
    'name' => '畅言评论',
    'version' => '1.0',
    'author' => 'CLTPHP',
    'desc' => '畅言评论插件 ',
    'icon' => 'logo.png',
    'config' => array(
        array('name' => 'app_id','label'=>'app_id','type' => 'text',   'value' => ''),
        array('name' => 'app_key','label'=>'app_key','type' => 'text',   'value' => ''),
        array('name' => 'config','label'=>'config','type' => 'text',   'value' => '')
    ),
    'scene'=>'',
    'bank_code'=>''
);